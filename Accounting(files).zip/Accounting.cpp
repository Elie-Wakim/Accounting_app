#include <iostream>
#include <ctime>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <algorithm>
using namespace std;
string formatWithCommas(double value) {
    // Convert double to string with fixed 2 decimals
    stringstream ss;
    ss << fixed << setprecision(2) << value;
    string s = ss.str();
    // Find decimal point
    size_t dotPos = s.find('.');
    // Integer part and fractional part
    string intPart = (dotPos == string::npos) ? s : s.substr(0, dotPos);
    string fracPart = (dotPos == string::npos) ? "" : s.substr(dotPos);
    // Insert commas in integer part
    int insertPosition = intPart.length() - 3;
    while (insertPosition > 0) {
        intPart.insert(insertPosition, ",");
        insertPosition -= 3;
    }
    return intPart + fracPart;
}
void tolowercase(string to_up){
transform(to_up.begin(),to_up.end(),to_up.begin(),[](unsigned char c){return tolower(c);});
}
double removeCommasAndConvertToDouble(const string& str) {
    string result;
    for (char c : str) {
        if (c != ',') {
            result += c;
        }
    }
    double doubleResult = 0.0;
    try {
        doubleResult = stod(result);
    } catch (...) {
        doubleResult = 0.0; 
    }
    return doubleResult;
}
void savetime(){
    time_t stime=time(0);
    ofstream save("data/savetime.csv", ios::app);
    save << ctime(&stime);
    save.close();
}
void readtime(vector <string>& t){
    ifstream read("data/savetime.csv");
    string line,ti;
    t.clear();
    while (getline(read,line))
    {
        stringstream ss(line);
        getline(ss,ti);
        t.push_back(ti);
    }read.close();
}
void savelbp(double lbpmon,int opt){
    ofstream savelb("data/savelbp.csv", ios::app);
    if(opt == 1)
    savelb << formatWithCommas(lbpmon)<<endl;
    if(opt==2)
    savelb << "-" + formatWithCommas(lbpmon)<<endl;
    savelb.close();
}
void saveusd(double usd,int opt){
    ofstream saveusd("data/saveusd.csv", ios::app);
    if(opt == 1)
    saveusd << formatWithCommas(usd) << endl;
    if(opt==2)
    saveusd << "-"+formatWithCommas(usd) << endl;
    saveusd.close();
}
void saveeur(double eur,int opt){
    ofstream saveeur("data/saveeur.csv", ios::app);
    if(opt == 1)
    saveeur << formatWithCommas(eur) <<endl;
    if(opt==2)
    saveeur << "-"+formatWithCommas(eur) <<endl;
    saveeur.close();
}
void readlbp(vector <string>& lbps){
    ifstream read("data/savelbp.csv");
    string line, leb;
    while(getline(read,line)){
         stringstream ss(line);
        getline(ss,leb);
        lbps.push_back(leb);
    }
    read.close();
}
void readusd(vector <string>& usds){
    ifstream read("data/saveusd.csv");
    string line, dol;
    while(getline(read,line)){
     stringstream ss(line);
        getline(ss,dol);
        usds.push_back(dol);
    }
    read.close();
}
void readeur(vector <string>& eurs){
    ifstream read("data/saveeur.csv");
    string line, euro;
    while(getline(read,line)){
        stringstream ss(line);
        getline(ss,euro);
        eurs.push_back(euro);
    }
    read.close();
}
void savemain(double lbp,double usd,double eur){
ofstream savemain("data/savemain.csv",ios::out);
savemain << lbp << endl << usd << endl << eur;
savemain.close();
}
void readmain(double &lbp,double &usd, double &eur,bool& found){
string line;
double mon;
int c=0;
ifstream readm("data/savemain.csv");
while (getline(readm,line))
{
    stringstream ss(line);
    ss >> mon;
    if (c==0)
    {
        lbp=mon;
    }if (c==1)
    {
        usd=mon;
    }else if (c == 2)
    eur=mon;
    c++;
    ss.ignore(1);
    found=true;
}
}
void saveinfo(string info){
    ofstream save("data/saveinfo.csv", ios::app);
    save << info << endl;
    save.close();
}
void readinfo(vector <string>& infos){
    string line,info;
    ifstream readinfo("data/saveinfo.csv");
    while (getline(readinfo,line))
    {
        stringstream ss(line);
        getline(ss,info);
        infos.push_back(info);
    }
}
void saveperson(string name){
ofstream savename("data/savenames.csv", ios::app);
savename << name << endl;
savename.close();
}
void readpersons(vector <string>& name){
    ifstream read("data/savenames.csv");
    string line,names;
    while (getline(read,line))
    {
        stringstream ss(line);
        getline(ss,names);
        name.push_back(names);
    }
}
void cni(){
    string cause,name;
    cout << "What's the cause: "; cin.ignore(1); getline(cin,cause);
    cout << "From/To who?: "; getline(cin,name);
    saveinfo(cause);
    saveperson(name);
}
void empty(vector <string>& a){
a.erase(a.begin(), a.end());
}
void savestatement(vector <string> lbps, vector <string> usds,vector <string> eur, vector <string> infos,vector <string> names,vector <string>times, vector <string> state){
ofstream saves("data/statement.csv", ios::out);
string statement;
empty(lbps);
empty(usds);
empty(eur);
empty(infos);
empty(names);
empty(times);
readlbp(lbps);readusd(usds);readeur(eur);readinfo(infos);readpersons(names);readtime(times);
for (int i = 0; i < times.size(); i++)
{
    statement = times[i] + "|" + lbps[i] + " LBP | " + usds[i] +" USD | "+ eur[i] + " EUR | From/To:"+ names[i] + " | Cause: " + infos[i];
    saves << statement << endl;
    state.push_back(statement);
}
saves.close();
}
void readstatement(){
    string line,state;
    ifstream read("data/statement.csv");
    while (getline(read,line))
    {
        stringstream ss(line);
       getline(ss,state);
       cout << state <<"\n";
    }for (int i = 0; i < 30; i++)
       {
        cout << "*";
       }cout << "\n";
    read.close();
}
void refreshstate(){
    ofstream savetime("data/savetime.csv", ios::out);
    savetime.close();
    ofstream savelb("data/savelbp.csv", ios::out);
    savelb.close();
    ofstream saveusds("data/saveusd.csv", ios::out);
    saveusds.close();
    ofstream saveeurs("data/saveeur.csv", ios::out);
    saveeurs.close();
    ofstream save("data/saveinfo.csv", ios::out);
    save.close();
    ofstream savename("data/savenames.csv", ios::out);
    savename.close();
    ofstream savest("data/statement.csv", ios::out);
}
void search(vector <string> statement,string keyword){
      bool found = false;
    for (const auto& line : statement) {
        if (line.find(keyword) != string::npos) {
            cout << "Found: " << line << endl;
            found = true;
        }
    }

    if (!found) {
        cout << "No match found.\n";
    }
}
int main(){
    int opt,curr;
    double amountlbp,amountusd,amounteur;
    vector <string> lebaneses,dollars,euros,informations,names,time,statement;
    string key;
    double lbp=0,usd=0,eur=0;
    bool found=false;
    readmain(lbp,usd,eur,found);
    if (found)
    {
    readlbp(lebaneses);
    readusd(dollars);
    readeur(euros);
    readinfo(informations);
    readpersons(names);
    readtime(time);
    }
    while(opt!=6){
    cout << "You have:\n" << formatWithCommas(lbp) << " LBP | " << formatWithCommas(usd) << " USD | " << formatWithCommas(eur) << " EUR | ";
    cout <<"Would you like to:\n 1-Add Money \n 2-Remove Money \n 3-View Statement\n 4-Refresh Statement\n 5-Search\n 6-Exit\n"; cin >> opt;
    if (opt == 1)
    {
            cout << "Enter the amount to be added in LBP: "; cin >> amountlbp;
            lbp+=amountlbp;
            cout << "Enter the amount to be added in USD: "; cin >> amountusd;
            usd+=amountusd;
          cout << "Enter the amount to be added in EUR: "; cin >> amounteur;
          eur+=amounteur;
          cni();
          savetime();
          savelbp(amountlbp,opt);
        saveusd(amountusd,opt);
        saveeur(amounteur,opt);
        savemain(lbp,usd,eur);
        savestatement(lebaneses,dollars,euros,informations,names,time,statement);
    }if (opt == 2)
    {
         cout << "Enter the amount to be removed in LBP: "; cin >> amountlbp;
         while(lbp < amountlbp){
           cout << "insufficient balance";
           cin >> amountlbp;
         }
          lbp-=amountlbp;
            cout << "Enter the amount to be removed in USD: "; cin >> amountusd;
            while(usd < amountusd){
           cout << "insufficient balance";
           cin >> amountusd;
         }
            usd-=amountusd;
          cout << "Enter the amount to be removed in EUR: "; cin >> amounteur;
          while(eur < amounteur){
           cout << "insufficient balance";
           cin >> amounteur;
         }
          eur-=amounteur;
          cni();
          savetime();
          savelbp(amountlbp,opt);
        saveusd(amountusd,opt);
        saveeur(amounteur,opt);
        savemain(lbp,usd,eur);
        savestatement(lebaneses,dollars,euros,informations,names,time,statement);
    }if (opt==3)
    {
        readstatement();
    }if (opt==4)
    {
        string sure;
        cout << "Are you Sure? y/n\n";
        cin >> sure;
        if (sure == "y")
        {
           refreshstate();
        }
    }
    if (opt == 5)
    {
        cout << "Type the word you're trying to search for: ";
        cin.ignore(1);
        getline(cin,key);
        search(statement,key);
    }
    
}
}